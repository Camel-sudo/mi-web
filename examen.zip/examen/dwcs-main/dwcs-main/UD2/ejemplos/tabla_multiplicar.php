<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla</title>
</head>

<body>
    <h1>Muestra la tabla de un número salvo los multiplos de 3</h1>
    <?php
      require('./funciones.php');
      multiplicar(4);
    ?>
</body>

</html>