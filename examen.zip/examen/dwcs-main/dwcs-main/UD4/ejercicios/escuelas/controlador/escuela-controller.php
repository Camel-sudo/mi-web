<?php
include_once("globals.php");
include_once(MODEL_PATH . "escuela-model.php");
include_once(MODEL_PATH . "municipio-model.php");
include_once(VIEW_PATH . "View.php");
class EscuelaController
{

    public function listar_escuelas($input_data = null)
    {
        $data = $input_data ?? [];
        $nombre_filter = $_REQUEST['nombre'] ?? '';
        $cod_municipio_filter = null;
        if (isset($_REQUEST['municipio']) && !empty($_REQUEST['municipio'])) {
            $cod_municipio_filter = $_REQUEST['municipio'];
        }

        $escuelas = EscuelaModel::get_escuelas($cod_municipio_filter, $nombre_filter);
        $view = new View();
        //Cargamos los datos para pasarle a la vista
        $data['escuelas'] = $escuelas;
        $data['municipios'] = MunicipioModel::get_municipios_escuelas();
        $data['filter_municipio'] = $cod_municipio_filter;
        $data['filter_nombre'] = $nombre_filter;
        $view->show('listar-escuelas', $data);

    }

    public function baja_escuela()
    {
        $data = null;
        if (isset($_REQUEST['cod_escuela'])) {
            $escuela = EscuelaModel::get_escuela($_REQUEST['cod_escuela']);
            $matriculas = EscuelaModel::get_num_matriculas_escuela($escuela);
            $data = ['eliminar' => ['escuela' => $escuela, 'matriculas' => $matriculas]];
            //Guardamos el codigo de la escuela en la sesión
            session_start();
            $_SESSION['escuela_to_delete'] = $escuela;
        }

        $this->listar_escuelas($data);
    }

    public function eliminar_escuela()
    {
        session_start();
        if (isset($_SESSION['escuela_to_delete'])) {
            EscuelaModel::baja_escuela($_SESSION['escuela_to_delete']);
            unset($_SESSION['escuela_to_delete']);
        }

        $this->listar_escuelas();
    }
    //funcion que nos cambia la vista a la de escuela
    public function formulario_añadir_escuela()
    {
        $view = new View();
        $data = [];
        $data['municipios'] = MunicipioModel::get_municipios_escuelas();
        $view->show('formulario-añadir-escuela', $data);
    }
    //funcion que nos añade una escuela
    //la valida y sanitiza
    public function añadir_escuela()
    {
        try {

            $nombre = htmlspecialchars($_POST["nombre"] ?? "");
            $direccion = htmlspecialchars($_POST["direccion"] ?? "");
            $apertura = new DateTime($_POST["apertura"]);
            $cierre = new DateTime($_POST["cierre"]);
            $comedor = strtolower($_POST["comedor"] ?? "") === 'S' ? TRUE : FALSE;
            $cod_municipio = htmlspecialchars($_POST["municipio"]);

            $db = ConnectionDB::get();
            $sql = "SELECT cod_municipio, nombre,latitud, longitud, altitud, cod_provincia FROM municipio m WHERE cod_municipio = ?";
            $statement = $db->prepare(query: $sql);
            $statement->bindValue(1, $cod_municipio, PDO::PARAM_INT);
            $municipio = [];
            $statement->execute();
            if ($row = $statement->fetch()) {
                $municipio = new Municipio($row['cod_municipio'], $row['nombre'], $row['longitud'], $row['latitud'], $row['altitud'], $row['cod_provincia']);
            } else {
                error_log("Municipio no encontrado");
            }
            if (!$nombre || !$direccion || !$apertura || !$cierre || !$municipio) {
                throw new Exception("Todos los campos obligatorios deben ser completados.");
            }
            $escuela = new Escuela();

            $escuela->setNombre($nombre)
                ->setDireccion($direccion)
                ->setHora_apertura($apertura)
                ->setHora_cierre($cierre)
                ->setComedor($comedor)
                ->setMunicipio($municipio);

            EscuelaModel::alta_escuela($escuela);

            $this->listar_escuelas();
        } catch (PDOException $th) {
            error_log("Error añadiendo escuela" . $th->getMessage());
        }

    }
    public function formulario_modificar_escuela()
    {
        $view = new View();
        $data = [];
        $data['municipios'] = MunicipioModel::get_municipios_escuelas();
        $view->show('formulario-modificar-escuela', $data);
    }
    public function modificar_escuela()
    {
        try {
            $nombre = htmlspecialchars($_POST["nombre"] ?? "");
            $direccion = htmlspecialchars($_POST["direccion"] ?? "");
            $apertura = new DateTime($_POST["apertura"]);
            $cierre = new DateTime($_POST["cierre"]);
            $comedor = strtolower($_POST["comedor"] ?? "") === 'S' ? TRUE : FALSE;
            $cod_municipio = htmlspecialchars($_POST["municipio"]);

            $db = ConnectionDB::get();
            $sql = "SELECT cod_municipio, nombre,latitud, longitud, altitud, cod_provincia FROM municipio m WHERE cod_municipio = ?";
            $statement = $db->prepare(query: $sql);
            $statement->bindValue(1, $cod_municipio, PDO::PARAM_INT);
            $municipio = [];
            $statement->execute();
            if ($row = $statement->fetch()) {
                $municipio = new Municipio($row['cod_municipio'], $row['nombre'], $row['longitud'], $row['latitud'], $row['altitud'], $row['cod_provincia']);
            } else {
                error_log("Municipio no encontrado");
            }
            if (!$nombre || !$direccion || !$apertura || !$cierre || !$municipio) {
                throw new Exception("Todos los campos obligatorios deben ser completados.");
            }
            $escuela = new Escuela();

            $escuela->setNombre($nombre)
                ->setDireccion($direccion)
                ->setHora_apertura($apertura)
                ->setHora_cierre($cierre)
                ->setComedor($comedor)
                ->setMunicipio($municipio);
            EscuelaModel::actualizar_escuela($escuela);

            $this->listar_escuelas();
        } catch (PDOException $th) {
            error_log("Error modficicando escuela" . $th->getMessage());
        }
    }
}