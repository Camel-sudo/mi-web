<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?=STYLE_PATH.'style.css'?>" rel="stylesheet">
    <title>Escuelas</title>
</head>

<body>
    <!-- AQUI EL HEADER -->
    <fieldset>
    <form action="?controller=EscuelaController&action=añadir_escuela" method="POST">
        <div>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Ingrese el nombre" required>
        </div>

        <div>
            <label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="direccion" placeholder="Ingrese la dirección" required>
        </div>

        <div>
            <label for="apertura">Apertura:</label>
            <input type="time" id="apertura" name="apertura" required>
        </div>

        <div>
            <label for="cierre">Cierre:</label>
            <input type="time" id="cierre" name="cierre" required>
        </div>

        <div>
            <label for="comedor">Comedor:</label>
            <select id="comedor" name="comedor" required>
                <option value="">Seleccione una opción</option>
                <option value="S">Sí</option>
                <option value="N">No</option>
            </select>
        </div>

        <div>
        <select id="municipio" name="municipio">
                <option value="">Todos los municipios</option>
                <?php
                foreach ($data['municipios'] as $m) {
                    echo '<option value="' . $m->getCodigo() .'" '.($m->getCodigo()==$data['filter_municipio']?'selected ':''). '>';
                    echo $m->getNombre();
                    echo '</option>';
                }
                ?>
            </select>
        </div>

        <div>
            <button type="submit">Enviar</button>
        </div>
    </form>
        <a href="index.php">lista de escuelas</a>
    </fieldset>
    <!-- AQUI EL FOOTER -->
</body>

</html>