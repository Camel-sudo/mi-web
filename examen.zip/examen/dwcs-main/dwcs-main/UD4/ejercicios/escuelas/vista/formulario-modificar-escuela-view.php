<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?=STYLE_PATH.'style.css'?>" rel="stylesheet">
    <title>Escuelas</title>
</head>
<?php
        session_start();
        $cod_escuela=$_REQUEST["cod_escuela"];
        $_SESSION["cod_escuela"]=$cod_escuela;
        $escuela=EscuelaModel::get_escuela($cod_escuela);
        var_dump($escuela->getComedor());
?>
<body>
    <!-- AQUI EL HEADER -->
    <fieldset>
    <form action="?controller=EscuelaController&action=modificar_escuela" method="POST">
        <div>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?= $escuela->getNombre(); ?>" required>
        </div>

        <div>
            <label for="direccion">Dirección:</label>
            <input type="text" id="direccion" name="direccion" value="<?= $escuela->getDireccion(); ?>"  required>
        </div>

        <div>
            <label for="apertura">Apertura:</label>
            <input type="time" id="apertura" name="apertura" value="<?= $escuela->getHora_apertura(); ?>" required>
        </div>

        <div>
            <label for="cierre">Cierre:</label>
            <input type="time" id="cierre" name="cierre" value="<?= $escuela->getHora_cierre(); ?>" required>
        </div>

        <div>
            <label for="comedor">Comedor:</label>
            <select id="comedor" name="comedor" required>
                <option value="">Seleccione una opción</option>
                <option value="S" <?= $escuela->getComedor()?"selected":"" ?>>Sí</option>
                <option value="N" <?= $escuela->getComedor()?"":"selected" ?>>No</option>
            </select>
        </div>

        <div>
        <select id="municipio" name="municipio">
                <option value="">Todos los municipios</option>
                <?php
                foreach ($data['municipios'] as $m) {
                    echo '<option value="' . $m->getCodigo() .'"';
                    echo ($m->getCodigo() == $escuela->getMunicipio()->getCodigo()?'selected':'');
                    echo '>';
                    echo $m->getNombre();
                    echo '</option>';
                }
                ?>
            </select>
        </div>

        <div>
            <button type="submit">Modificar</button>
        </div>
    </form>
        <a href="index.php">lista de escuelas</a>
    </fieldset>
    <!-- AQUI EL FOOTER -->
</body>

</html>