<?php
//CAMBIE $SERVER_DOCUMENT POR DIR pq en mi estructura de archivos no me funcionaba
define("MODEL_PATH", __DIR__ . '/modelo/');
define("CONTROLLER_PATH", __DIR__ . '/controlador/');
define("VIEW_PATH", __DIR__ . '/vista/');
define("IMG_PATH", '/vista/img/');
define("STYLE_PATH", '/vista/estilos/');
?>
