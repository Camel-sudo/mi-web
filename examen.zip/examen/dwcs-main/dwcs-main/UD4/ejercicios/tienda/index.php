<?php
include("controlador/tienda-controller.php");

if (isset($_REQUEST["controller"])) {
    $controller = $_REQUEST["controller"];
    try {
        $objeto = new $controller();

        if (isset($_REQUEST["action"])) {
            $action=$_REQUEST["action"];
        }
        $objeto->action();
    } catch (\Throwable $th) {
        echo("hola");
        error_log("Cargando controlador inexistente ".$controller);
        $objeto=new TiendaController();
        $objeto->listar_escuelas();
    }
}else{
    $objeto = new TiendaController();
    $objeto->listar_escuelas();
}