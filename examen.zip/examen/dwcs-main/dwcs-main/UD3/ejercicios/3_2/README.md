# Actividad 3.2: Juego del número secreto
## 1. Vamos a escribir una aplicación web en PHP para jugar al juego del número secreto.
Es un juego clásico que consiste en lo siguiente: el ordenador elegirá un número al azar entre 1 y 1000 y el jugador tendrá que averiguarlo. Cada vez que el jugador haga un intento, la aplicación le indicará si el número secreto es mayor o menor que el número introducido.
Cuando el jugador por fin acierte, la aplicación le dará la enhorabuena y le indicará cuántos intentos ha necesitado para averiguar el número secreto y cuanto tiempo ha tardado en acertarlo.

## 2. Amplia el juego para que el número máximo de intentos sea 10. Una vez alcanzado este número el programa le indicará al usuario que ha perdido y le mostrará la solución.

## 3. Amplia el juego para que, antes de empezar a jugar, el usuario pueda introducir un nombre de usuario. Debe almacenarse en una base de datos, las victorias de cada usuario, registrando el número a acertar, los intentos empleados y el tiempo que ha tardado en acertarlo. Estos resultados podrán consultarse en una página ranking.